import React from "react";


function Notes() {
  return <div className="note">
    <h1>This is the React Bootcamp</h1>
    <p>All the students who complete the bootcamp with complete attendance and project submission will be rewarded certificates from us</p>
  </div>;
}
   
  


export default Notes;
